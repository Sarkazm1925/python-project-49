#!/usr/bin/env python3

from brain_games import welcome_user1


def main():
    welcome_user1()


if __name__ == '__main__':
    main()
