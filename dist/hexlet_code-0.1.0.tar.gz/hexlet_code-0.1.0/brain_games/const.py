GAME_LIMIT = 3
SIGNS = ["+", "-", "*"]
TEXT = "is wrong answer ;(. Correct answer was"
